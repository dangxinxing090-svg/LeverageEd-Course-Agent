#!/bin/bash
# AI智能教育课程平台 - Linux VM 一键启动脚本
# 适用于 SOLO Linux 虚拟机环境
# 双击或在终端运行: bash start_linux.sh

set -e

# ==================== 配置 ====================
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKEND_DIR="$SCRIPT_DIR/backend"
FRONTEND_DIR="$SCRIPT_DIR/frontend"
PID_FILE="$SCRIPT_DIR/.service_pids"
BACKEND_LOG="$SCRIPT_DIR/backend.log"
FRONTEND_LOG="$SCRIPT_DIR/frontend.log"

PG_BIN="/usr/local/pgsql/bin"
PG_DATA="/usr/local/pgsql/data"

BACKEND_PORT=8000
FRONTEND_PORT=5173

# 颜色
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}  AI智能教育课程平台 - Linux 启动${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

# ==================== 工具函数 ====================

stop_pid() {
    local pid="$1"
    if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
        kill "$pid" 2>/dev/null || true
    fi
}

wait_for_url() {
    local url="$1" name="$2" max_wait="${3:-45}"
    for ((i = 1; i <= max_wait; i++)); do
        if curl -fsS "$url" >/dev/null 2>&1; then
            echo -e "${GREEN}✓ ${name} 可用${NC}"
            return 0
        fi
        sleep 1
    done
    echo -e "${RED}${name} 启动超时${NC}"
    return 1
}

# ==================== 步骤 1: 清理旧进程 ====================
echo -e "${YELLOW}[1/6] 清理旧进程...${NC}"
if [ -f "$PID_FILE" ]; then
    while read pid; do
        stop_pid "$pid"
    done < "$PID_FILE"
    rm -f "$PID_FILE"
fi
pkill -f "uvicorn app.main:app" 2>/dev/null || true
pkill -f "vite" 2>/dev/null || true
sleep 1
echo -e "${GREEN}✓ 旧进程已清理${NC}"

# ==================== 步骤 2: 启动 PostgreSQL ====================
echo -e "${YELLOW}[2/6] 检查 PostgreSQL...${NC}"
if ! su - postgres -c "$PG_BIN/pg_ctl status -D $PG_DATA" 2>/dev/null; then
    echo -e "${YELLOW}启动 PostgreSQL...${NC}"
    su - postgres -c "$PG_BIN/pg_ctl start -D $PG_DATA -l $PG_DATA/logfile" 2>/dev/null || true
    sleep 2
fi

# 验证 PostgreSQL
if su - postgres -c "$PG_BIN/psql -U postgres -c 'SELECT 1'" >/dev/null 2>&1; then
    echo -e "${GREEN}✓ PostgreSQL 运行中${NC}"
else
    echo -e "${RED}✗ PostgreSQL 无法连接${NC}"
    exit 1
fi

# ==================== 步骤 3: 检查/创建虚拟环境 ====================
echo -e "${YELLOW}[3/6] 检查 Python 虚拟环境...${NC}"
if [ ! -f "$BACKEND_DIR/venv/bin/python" ] || ! "$BACKEND_DIR/venv/bin/python" --version >/dev/null 2>&1; then
    echo -e "${YELLOW}创建虚拟环境...${NC}"
    # 在临时目录创建 venv，避免 Mac 文件同步干扰
    rm -rf "$BACKEND_DIR/venv"
    TMP_VENV="/tmp/ai_edu_venv_$$"
    rm -rf "$TMP_VENV"
    python3 -m venv "$TMP_VENV"
    echo -e "${YELLOW}安装依赖（可能需要几分钟）...${NC}"
    "$TMP_VENV/bin/pip" install -r "$BACKEND_DIR/requirements.txt" -q
    # 复制到项目目录
    cp -r "$TMP_VENV" "$BACKEND_DIR/venv"
    rm -rf "$TMP_VENV"
    echo -e "${GREEN}✓ 虚拟环境已创建${NC}"
else
    echo -e "${GREEN}✓ 虚拟环境可用${NC}"
fi

# ==================== 步骤 4: 初始化数据库 ====================
echo -e "${YELLOW}[4/6] 初始化数据库...${NC}"
cd "$BACKEND_DIR"
"$BACKEND_DIR/venv/bin/python" init_database.py 2>/dev/null || true
echo -e "${GREEN}✓ 数据库就绪${NC}"

# ==================== 步骤 5: 启动后端 ====================
echo -e "${YELLOW}[5/6] 启动后端服务...${NC}"
cd "$BACKEND_DIR"
: > "$BACKEND_LOG"
"$BACKEND_DIR/venv/bin/python" -m uvicorn app.main:app \
    --host 0.0.0.0 --port $BACKEND_PORT \
    > "$BACKEND_LOG" 2>&1 &
BACKEND_PID=$!
echo $BACKEND_PID >> "$PID_FILE"

wait_for_url "http://localhost:$BACKEND_PORT/health" "后端服务" 30

# ==================== 步骤 6: 启动前端 ====================
echo -e "${YELLOW}[6/6] 启动前端服务...${NC}"
cd "$FRONTEND_DIR"

if [ ! -d "node_modules" ]; then
    echo -e "${YELLOW}安装前端依赖（可能需要几分钟）...${NC}"
    npm install --legacy-peer-deps -q
fi

: > "$FRONTEND_LOG"
npm start > "$FRONTEND_LOG" 2>&1 &
FRONTEND_PID=$!
echo $FRONTEND_PID >> "$PID_FILE"

wait_for_url "http://localhost:$FRONTEND_PORT" "前端页面" 30

# ==================== 完成 ====================
echo ""
echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}  🎉 项目启动成功！${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""
echo -e "  前端地址：${BLUE}http://localhost:$FRONTEND_PORT/${NC}"
echo -e "  后端 API：${BLUE}http://localhost:$BACKEND_PORT/docs${NC}"
echo ""
echo -e "${YELLOW}停止服务：./stop.sh${NC}"
echo -e "${YELLOW}查看日志：tail -f backend.log / frontend.log${NC}"
echo ""

# 打开浏览器
if command -v xdg-open >/dev/null 2>&1; then
    xdg-open "http://localhost:$FRONTEND_PORT/" 2>/dev/null &
elif command -v open >/dev/null 2>&1; then
    open "http://localhost:$FRONTEND_PORT/" 2>/dev/null &
fi
